#include <stdio.h>
#include <stdlib.h>
#include "filadeints.h"

int main(){
    Fila *fi; 
//criafila,  colocanafila,  tiradafila,  filavazia  e  filacheia. 
    fi =  criafila();

    int a = colocanafila(fi, 50);
    printf("%d\n", a);

    int x = tamanhofila(fi);
		printf("%d\n", x);

    int b = tiradafila(fi);
		printf("%d\n", b);

    int y = filacheia(fi);
		printf("%d\n", y);

    int z = filavazia(fi);
		printf("%d\n", z);

    liberafila(fi);

/*A fila deve ter um indicador de tamanho máximo de elementos, bem como os índices que indicam o início e o fim da fila. 
Escreva também uma interface filadeints.h  para o módulo. 
*/
//inserções e exclusões de elementos ocorrem nas extremidades da "lista"
//cada elemento aponta para seu sucessor na lista
//usa um nó descritor para representar o início e final da fila e uma indicação de final de fila

}


