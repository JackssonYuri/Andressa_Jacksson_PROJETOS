#include <stdio.h>
#include <stdlib.h>
#include "ListaEncadeadaSimples.h"

int main(){
    Lista* li; 
//criafila,  colocanafila,  tiradafila,  filavazia  e  filacheia. 
    li =  cria_lista();

    int a = inserirInicio(li, 50);
    printf("%d\n", a);

    int b = remove_matricula(li, 50);
		printf("%d\n", b);

    int z = lista_vazia(li);
		printf("%d\n", z);

    libera(li);


/*A fila deve ter um indicador de tamanho máximo de elementos, bem como os índices que indicam o início e o fim da fila. 
Escreva também uma interface filadeints.h  para o módulo. 
*/
//inserções e exclusões de elementos ocorrem nas extremidades da "lista"
//cada elemento aponta para seu sucessor na lista
//usa um nó descritor para representar o início e final da fila e uma indicação de final de fila

}