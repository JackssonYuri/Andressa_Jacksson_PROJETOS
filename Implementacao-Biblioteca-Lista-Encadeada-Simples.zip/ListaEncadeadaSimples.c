#include <stdio.h>
#include <stdlib.h>
#include "ListaEncadeadaSimples.h"
//Jacksson Yuri e Andressa Nunes

/* função para inicializar a lista
@param função para inicializar a lista como nula
*/
Lista *inicializa()
{
	return NULL;
}

/*função cria lista
@param Função para criar a lista
*/
Lista *cria_lista()
{
	Lista *lista = (Lista*)malloc(sizeof(Lista));
	if(lista!=NULL)
		*lista = NULL; 
	return lista;
}
/*A função recebe a lista e retorna 1 se estiver vazia ou 0 se não estiver vazia. Como
@param lista - Função para saber se a lista está vazia
@returns - Retorna 1 se estiver vazia 
*/
int lista_vazia(Lista *lista)
{
  if (lista ==NULL)
  return 1;
  if(*lista==NULL)
  return 1;
   
	 return 0;
}
/* @param - Insere elemento no inicio da lista 
	@returns Retorna 1 se a lista for nula
*/
int inserirInicio(Lista *lista, int valor){
	if(lista == NULL){
		return 1;
}
    No *novo = (No*)malloc(sizeof(No));
    novo -> valor = valor; 
    novo -> proximo = *lista ;
    *lista = novo;
	return 0;
}
/* @param libera valores da lista */
void libera (Lista* lista)
{
 if(lista != NULL){ //a lista é válida se passar daqui
		Lista no;
			while((*lista) != NULL){
				no = *lista;
        lista = &(*lista)->proximo;
        free(no);
			}
 }
}
/* @param imprime valores dos elementos da lista */
void imprimir (Lista* lista)
{
 Lista p; /* variável auxiliar para percorrer a lista */
 for (p = *lista; p != NULL; p = p->proximo)
 	printf("impressao : %d\n", p -> valor);

}
/* @param remove valores da lista */
int remove_matricula(Lista* lista, int val)
{
  if(lista != NULL){

    Lista p = *lista;
    if((*lista)->valor == val){
      *lista = p->proximo;
      free(p);
      return 0;
    }

    Lista ant = p;

    for(p = p->proximo; p != NULL; p = p->proximo){
      if (p->valor == val){
        ant->proximo = p->proximo;
        free(p);
        break;
      }
      ant = ant->proximo;
      ant = p;
    }
    return 0;
  }
  return 1;
}