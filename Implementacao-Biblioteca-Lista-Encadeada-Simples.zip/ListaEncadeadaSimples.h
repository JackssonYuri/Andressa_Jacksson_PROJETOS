#ifndef LISTAENCADEADASIMPLES_H
#define LISTAENCADEADASIMPLES_H

#include <stdio.h>
#include <stdlib.h>

typedef struct No
{
    int valor;
    struct No *proximo;
} No;
typedef struct No* Lista;

typedef struct lista_com_tam
{
    Lista *inicio;
    int tam;
}  Lista_tam;

/* @param função que inicializa a lista como vazia */
Lista*inicializa();
/* @param função cria lista */
Lista *cria_lista(); 
/* @param função para testar se a lista é vazia */
int lista_vazia(Lista *lista); 
/* @param função para inserir no inicio da lista */
int inserirInicio(Lista *lista, int valor);
/* @param função para remover na lista */
int remove_matricula(Lista* lista, int val);
/* @param função para imprimir a lista */
void imprimir (Lista* lista);
/* @param função para liberar a lista*/
void libera (Lista* lista);

#endif