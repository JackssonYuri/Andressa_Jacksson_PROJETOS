#ifndef FILADEINTS_H
#define FILADEINTS_H
#define TAM_MAX 100

#include <stdio.h>
#include <stdlib.h>

typedef struct No
{
    int valor;
    struct No *proximo;
} No;


typedef struct fila
{
		struct No *inicio;
		struct No *final;
		int tam;
}Fila;

/* função para criar a fila */
Fila* criafila();
/* função para liberar a fila */
void liberafila(Fila* fi);
/* função para informar o tamanho da fila, retorna a variável cont */
int tamanhofila(Fila* fi);
/* função para verificar se a fila está cheia, caso esteja cheia retorna 1, caso não retorna 0 */
int filacheia(Fila* fi);
/* função para verificar se a fila está vazia, retorna 1 se estiver vazia e 0 se não.*/
int filavazia(Fila* fi);
/* função para inserir na fila, se retornar 0 é pq não existe uma fila, retorna 1 se deu tudo certo */
int colocanafila(Fila* fi, int valor);
/* função para remover da fila, retorna 1 se deu tudo certo */
int tiradafila(Fila* fi);

#endif